package com.ilhammuhammadariq.quizroom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class EditMahasiswa extends AppCompatActivity {
    private EditText npm, nama_depan,nama_belakang,username,password,email,no_telepon;
    private Spinner program_studi;
    private AppDatabase database;
    private Button bUpdate;
    private RadioButton laki_laki,perempuan;
    private Mahasiswa mahasiswa;
    private String myJenisKelamin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_mahasiswa);
        getSupportActionBar().setTitle("Edit Data Mahasiswa");

        npm = findViewById(R.id.etE_Npm);
        nama_depan = findViewById(R.id.etE_namaDepan);
        nama_belakang = findViewById(R.id.etE_namaBelakang);
        username = findViewById(R.id.etE_username);
        password = findViewById(R.id.etE_password);
        email = findViewById(R.id.etE_email);
        laki_laki = findViewById(R.id.rdLaki);
        perempuan = findViewById(R.id.rdPerempuan);

        if(laki_laki.isChecked()){
            myJenisKelamin = "Laki-Laki";
        }else if (perempuan.isChecked()){
            myJenisKelamin = "Perempuan";
        }

        no_telepon = findViewById(R.id.etE_Notelepon);
        program_studi = findViewById(R.id.spEJurusan);

        bUpdate = findViewById(R.id.btn_update);

        database = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "dbMahasiswa").build();

        //Menampilkan data mahasiswa yang akan di edit
        getDataMahasiswa();

        bUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mahasiswa.setNpm(npm.getText().toString());
                mahasiswa.setNama_depan(nama_depan.getText().toString());
                mahasiswa.setNama_belakang(nama_belakang.getText().toString());
                mahasiswa.setUsername(username.getText().toString());
                mahasiswa.setPassword(password.getText().toString());
                mahasiswa.setEmail(email.getText().toString());
                mahasiswa.setJenis_kelamin(myJenisKelamin);
                mahasiswa.setNo_telepon(no_telepon.getText().toString());
                mahasiswa.setProgram_studi(program_studi.getSelectedItem().toString());
                updateData(mahasiswa);
            }
        });
    }

    private void getDataMahasiswa(){
        //Mendapatkan data dari Intent
        mahasiswa = (Mahasiswa)getIntent().getSerializableExtra("data");

        npm.setText(mahasiswa.getNpm());
        nama_depan.setText(mahasiswa.getNama_depan());
        nama_belakang.setText(mahasiswa.getNama_belakang());
        username.setText(mahasiswa.getUsername());
        password.setText(mahasiswa.getPassword());
        email.setText(mahasiswa.getEmail());
        switch (mahasiswa.getJenis_kelamin()){
            case "Laki-Laki":
                laki_laki.setChecked(true);
                myJenisKelamin = "Laki-Laki";
                break;
            case "Perempuan":
                perempuan.setChecked(true);
                myJenisKelamin = "Perempuan";
                break;
        }
        no_telepon.setText(mahasiswa.getNo_telepon());
        switch (mahasiswa.getProgram_studi()){
            case "Teknik Informatika":
                program_studi.setSelection(0);
                break;
            case "Manajemen Informatika":
                program_studi.setSelection(1);
                break;
            case "Logistik Bisnis":
                program_studi.setSelection(2);
                break;
            case "Akutansi":
                program_studi.setSelection(3);
                break;
        }

    }

    @SuppressLint("StaticFieldLeak")
    private void updateData(final Mahasiswa mahasiswa){
        new AsyncTask<Void, Void, Integer>() {
            @Override
            protected Integer doInBackground(Void... voids) {
                //Menjalankan proses update data
                return database.mahasiswaDAO().updateMahasiswa(mahasiswa);
            }

            @Override
            protected void onPostExecute(Integer status) {
                //Menandakan bahwa data berhasil disimpan
                Toast.makeText(EditMahasiswa.this, "Data Berhasil Diubah", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(EditMahasiswa.this, LihatDataMahasiswa.class));
                finish();
            }
        }.execute();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(EditMahasiswa.this, LihatDataMahasiswa.class));
        finish();
    }
}
