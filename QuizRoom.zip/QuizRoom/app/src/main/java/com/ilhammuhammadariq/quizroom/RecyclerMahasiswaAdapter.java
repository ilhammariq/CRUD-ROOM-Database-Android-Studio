package com.ilhammuhammadariq.quizroom;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EdgeEffect;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.ArrayList;

public class RecyclerMahasiswaAdapter extends RecyclerView.Adapter<RecyclerMahasiswaAdapter.ViewHolder>{

    //Deklarasi Variable
    private ArrayList<Mahasiswa> daftarMahasiswa;
    private AppDatabase appDatabase;
    private Context context;

    public RecyclerMahasiswaAdapter(ArrayList<Mahasiswa> daftarMahasiswa, Context context) {

        //Inisialisasi data yang akan digunakan
        this.daftarMahasiswa = daftarMahasiswa;
        this.context = context;
        appDatabase = Room.databaseBuilder(
                context.getApplicationContext(),
                AppDatabase.class, "dbMahasiswa").allowMainThreadQueries().build();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        //Deklarasi View yang akan digunakan
        private TextView user_id,npm,nama_depan,nama_belakang,username,
                password,email,jenis_kelamin,no_telepon,program_studi;
        private CardView item;

        ViewHolder(View itemView) {
            super(itemView);
            user_id = itemView.findViewById(R.id.tv_user_id);
            npm = itemView.findViewById(R.id.tv_npm);
            nama_depan = itemView.findViewById(R.id.tv_namaDepan);
            nama_belakang = itemView.findViewById(R.id.tv_namaBelakang);
            username = itemView.findViewById(R.id.tv_username);
            password = itemView.findViewById(R.id.tv_password);
            email = itemView.findViewById(R.id.tv_email);
            jenis_kelamin = itemView.findViewById(R.id.tv_jenisKelamin);
            no_telepon = itemView.findViewById(R.id.tv_noTelepon);
            program_studi = itemView.findViewById(R.id.tv_programStudi);
            item = itemView.findViewById(R.id.cvMahasiswa);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Inisialisasi Layout Item untuk RecyclerView
        View v =  LayoutInflater.from(parent.getContext()).inflate(R.layout.datamahasiswa, parent, false);
        return new ViewHolder(v);
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        //Deklarasi Variable untuk mendapatkan data dari Database melalui Array
        int UserId = daftarMahasiswa.get(position).getUser_id();
        String id = String.valueOf(UserId);
        String npm = daftarMahasiswa.get(position).getNpm();
        String nama_depan = daftarMahasiswa.get(position).getNama_depan();
        String nama_belakang = daftarMahasiswa.get(position).getNama_belakang();
        String username = daftarMahasiswa.get(position).getUsername();
        String password = daftarMahasiswa.get(position).getPassword();
        String email = daftarMahasiswa.get(position).getEmail();
        String jenis_kelamin = daftarMahasiswa.get(position).getJenis_kelamin();
        String no_telepon = daftarMahasiswa.get(position).getNo_telepon();
        String program_studi = daftarMahasiswa.get(position).getProgram_studi();


        //Menampilkan data berdasarkan posisi Item dari RecyclerView
        holder.user_id.setText(id);
        holder.npm.setText(npm);
        holder.nama_depan.setText(nama_depan);
        holder.nama_belakang.setText(nama_belakang);
        holder.username.setText(username);
        holder.password.setText(password);
        holder.email.setText(email);
        holder.jenis_kelamin.setText(jenis_kelamin);
        holder.no_telepon.setText(no_telepon);
        holder.program_studi.setText(program_studi);

        holder.item.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                CharSequence[] menuPilihan = {"Edit", "Delete"};
                AlertDialog.Builder dialog = new AlertDialog.Builder(v.getContext())
                        .setTitle("Pilih Aksi")
                        .setItems(menuPilihan, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which){
                                    case 0:
                                        onEditData(position, context);
                                        break;

                                    case 1:
                                        onDeleteData(position);
                                        break;
                                }
                            }
                        });
                dialog.create();
                dialog.show();
                return true;
            }
        });
    }

    private void onEditData(int position, Context context){
        context.startActivity(new Intent(context, EditMahasiswa.class).putExtra("data", daftarMahasiswa.get(position)));
        ((Activity)context).finish();
    }

    private void onDeleteData(int position){
        appDatabase.mahasiswaDAO().deleteMahasiswa(daftarMahasiswa.get(position));
        daftarMahasiswa.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, daftarMahasiswa.size());
        Toast.makeText(context, "Data Berhasil Dihapus", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int getItemCount() {
        //Menghitung data / ukuran dari Array
        return daftarMahasiswa.size();
    }
}
