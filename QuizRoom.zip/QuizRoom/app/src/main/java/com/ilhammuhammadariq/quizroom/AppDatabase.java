package com.ilhammuhammadariq.quizroom;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Mahasiswa.class,User.class}, version = 1,exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract MahasiswaDAO mahasiswaDAO();
    public abstract UserDAO userDAO();

}
