package com.ilhammuhammadariq.quizroom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText username, password;
    private Button login,regis;
    private AppDatabase database;
    private UserDAO userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.et_username);
        password = findViewById(R.id.et_password);

        login = findViewById(R.id.btn_login);
        regis = findViewById(R.id.btn_regis);

        database = Room.databaseBuilder(this,AppDatabase.class, "dbMahasiswa").allowMainThreadQueries().build();

        userDao = database.userDAO();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
                    Toast.makeText(LoginActivity.this, "Masukan Username dan Password", Toast.LENGTH_SHORT).show();
                }else{
                    User user = userDao.getUser(username.getText().toString(),password.getText().toString());
                    if (user != null){
                        Toast.makeText(LoginActivity.this, "Login Berhasil", Toast.LENGTH_SHORT).show();
                        Intent mahasiswa = new Intent(LoginActivity.this,MahasiswaActivity.class);
                        startActivity(mahasiswa);
                        finish();
                    }else{
                        Toast.makeText(LoginActivity.this, "Username atau Password Salah", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        regis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
                    Toast.makeText(LoginActivity.this, "Masukan Username dan Password", Toast.LENGTH_SHORT).show();
                }else{
                    User user = userDao.getUsername(username.getText().toString());
                    if(user!=null){
                        Toast.makeText(LoginActivity.this, "Username Telah digunakan", Toast.LENGTH_SHORT).show();
                    }else{
                    User data = new User();
                    data.setUsername(username.getText().toString());
                    data.setPassword(password.getText().toString());
                    insertData(data);
                    username.setText("");
                    password.setText("");
                    }
                }
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private void insertData(final User user){
        new AsyncTask<Void, Void, Long>() {
            @Override
            protected Long doInBackground(Void... voids) {
                //Menjalankan proses insert data
                return database.userDAO().insertUser(user);
            }
            @Override
            protected void onPostExecute(Long status) {
                //Menandakan bahwa registrasi berhasil
                Toast.makeText(LoginActivity.this, "Registrasi Berhasil ", Toast.LENGTH_SHORT).show();
            }
        }.execute();
    }
}

