package com.ilhammuhammadariq.quizroom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MahasiswaActivity extends AppCompatActivity {
    private EditText npm, nama_depan, nama_belakang, username, password, email, no_telepon;
    private Spinner program_studi;
    private AppDatabase database;
    private Button bSimpan, bLihatData;
    RadioButton kelamin;
    private RadioGroup jenis_kelamin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mahasiswa);
        getSupportActionBar().setTitle("Input Data Mahasiswa");

        npm = findViewById(R.id.et_Npm);
        nama_depan = findViewById(R.id.et_namaDepan);
        nama_belakang = findViewById(R.id.et_namaBelakang);
        username = findViewById(R.id.et_username);
        password = findViewById(R.id.et_password);
        email = findViewById(R.id.et_email);
        no_telepon = findViewById(R.id.et_Notelepon);
        program_studi = findViewById(R.id.spJurusan);

        bSimpan = findViewById(R.id.btn_simpan);
        bLihatData = findViewById(R.id.btn_lihat);


        database = Room.databaseBuilder(this, AppDatabase.class, "dbMahasiswa").allowMainThreadQueries().build();

        bSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jenis_kelamin = findViewById(R.id.rgKelamin);
                int selectedId = jenis_kelamin.getCheckedRadioButtonId();
                kelamin = findViewById(selectedId);

                if (npm.getText().toString().isEmpty() || nama_depan.getText().toString().isEmpty()
                        || nama_belakang.getText().toString().isEmpty() || username.getText().toString().isEmpty()
                        || password.getText().toString().isEmpty() || email.getText().toString().isEmpty()
                        || selectedId == -1 || no_telepon.getText().toString().isEmpty()) {
                    Toast.makeText(MahasiswaActivity.this, "Data TIdak Boleh Kosong", Toast.LENGTH_SHORT).show();
                } else {
                    //Membuat Instance/Objek Dari Class Entity Mahasisiwaa
                    Mahasiswa data = new Mahasiswa();
                    //Memasukan data yang diinputkan user pada database
                    data.setNpm(npm.getText().toString());
                    data.setNama_depan(nama_depan.getText().toString());
                    data.setNama_belakang(nama_belakang.getText().toString());
                    data.setUsername(username.getText().toString());
                    data.setPassword(password.getText().toString());
                    data.setEmail(email.getText().toString());
                    data.setJenis_kelamin(kelamin.getText().toString());
                    data.setNo_telepon(no_telepon.getText().toString());
                    data.setProgram_studi(program_studi.getSelectedItem().toString());
                    insertData(data);

                    //Mengembalikan EditText menjadi seperti semula\
                    npm.setText("");
                    nama_depan.setText("");
                    nama_belakang.setText("");
                    username.setText("");
                    password.setText("");
                    email.setText("");
                    jenis_kelamin.clearCheck();
                    no_telepon.setText("");
                }
            }
        });

        bLihatData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lihat = new Intent(MahasiswaActivity.this, LihatDataMahasiswa.class);
                startActivity(lihat);
            }
        });
    }


    @SuppressLint("StaticFieldLeak")
    private void insertData(final Mahasiswa mahasiswa) {
        new AsyncTask<Void, Void, Long>() {
            @Override
            protected Long doInBackground(Void... voids) {
                //Menjalankan proses insert data
                return database.mahasiswaDAO().insertMahasiswa(mahasiswa);
            }

            @Override
            protected void onPostExecute(Long status) {
                //Menandakan bahwa data berhasil disimpan
                Toast.makeText(MahasiswaActivity.this, "Data Berhasil Disimpan ", Toast.LENGTH_SHORT).show();
            }
        }.execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.logout) {
            startActivity(new Intent(this, LoginActivity.class));
            Toast.makeText(this, "Anda Berhasil Logout", Toast.LENGTH_SHORT).show();
        }
        return true;
    }
}

