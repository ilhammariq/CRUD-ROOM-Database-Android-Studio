package com.ilhammuhammadariq.quizroom;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface UserDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertUser(User user);

    @Query("SELECT * FROM tUser WHERE username= :username and password= :password")
    User getUser(String username,String password);

    @Query("SELECT * FROM tUser WHERE username= :username")
    User getUsername(String username);
}
