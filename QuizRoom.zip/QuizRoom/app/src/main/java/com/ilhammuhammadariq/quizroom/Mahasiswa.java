package com.ilhammuhammadariq.quizroom;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "tMahasiswa") //Membuat tabel baru dengan nama "tMahasiswa"
public class Mahasiswa implements Serializable {

    @NonNull
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "user_id")
    private
    int user_id;


    @ColumnInfo(name = "npm")
    private
    String npm;

    @ColumnInfo(name = "nama_depan")
    private
    String nama_depan;

    @ColumnInfo(name = "nama_belakang")
    private
    String nama_belakang;

    @ColumnInfo(name = "username")
    private
    String username;

    @ColumnInfo(name = "password")
    private
    String password;

    @ColumnInfo(name = "email")
    private
    String email;

    @ColumnInfo(name = "jenis_kelamin")
    private
    String jenis_kelamin;

    @ColumnInfo(name = "no_telepon")
    private
    String no_telepon;

    @ColumnInfo(name = "program_studi")
    private
    String program_studi;

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getNpm() {
        return npm;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getNama_depan() {
        return nama_depan;
    }

    public void setNama_depan(String nama_depan) {
        this.nama_depan = nama_depan;
    }

    public String getNama_belakang() {
        return nama_belakang;
    }

    public void setNama_belakang(String nama_belakang) {
        this.nama_belakang = nama_belakang;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public void setJenis_kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }

    public String getNo_telepon() {
        return no_telepon;
    }

    public void setNo_telepon(String no_telepon) {
        this.no_telepon = no_telepon;
    }

    public String getProgram_studi() {
        return program_studi;
    }

    public void setProgram_studi(String program_studi) {
        this.program_studi = program_studi;
    }
}
